package toxiccleanup.builder.weather;

import toxiccleanup.engine.game.Positionable;
import toxiccleanup.engine.timing.TickTimer;
import toxiccleanup.builder.SpriteGallery;

/**
 * <p> A {@link Cloud} is a weather phenomena that will move to the left, over time. </p>
 * <p> It obscures {@link toxiccleanup.builder.machines.SolarPanel}s that
 * it is sharing a tile with. </p>
 * <p> When it reaches the leftmost edge of the screen, it will mark itself for removal. </p>
 *
 * <p> Rendered using {@link SpriteGallery#cloud}. </p>
 *
 * @provided
 */
public class Cloud extends Cloudable {
    /**
     * Constructs a new Cloud at the given position.
     *
     * @param position the position to place the cloud at
     */
    public Cloud(Positionable position) {
        super(position, SpriteGallery.cloud);
    }

    /**
     * Constructs a new Cloud with custom movement timer (for testing).
     *
     * @param position the position to place the cloud at
     * @param movementTimer custom movement timer
     */
    public Cloud(Positionable position, TickTimer movementTimer) {
        super(position, SpriteGallery.cloud, movementTimer);
    }
}
